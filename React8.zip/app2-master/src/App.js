import logo from './logo.svg';
import './App.css';
import CustomButtom from './component/CustomButtom';
function App() {
  return (
    <div className="App">
      
     <CustomButtom/>
    </div>
  );
}

export default App;
